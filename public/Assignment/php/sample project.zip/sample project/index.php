<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/cdn.jsdelivr.net_npm_bootstrap@5.0.2_dist_css_bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <?php include("includes/header.php") ?>

    <div class="container mt-2">
        <div class="row">
            <div class="col-md-8">
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                </p>

                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                </p>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis quidem nostrum ipsam suscipit harum modi, itaque dolore nemo. Quidem aut blanditiis repudiandae corporis esse dolorum quos quas commodi eaque possimus.
                </p>
            </div>
            <div class="col-md-4">
                <?php include("includes/body.php") ?>
            </div>
        </div>
    </div>

    <script src="js/bootstrap.min.js"></script>
    <script src="js/code.jquery.com_jquery-3.7.0.min.js"></script>
    <script src="js/script.js"></script>
</body>

</html>