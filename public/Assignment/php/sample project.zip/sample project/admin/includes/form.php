<div class="bg-white p-3 m-5">
    <h2>forms Page</h2> 
    <hr>
    <h5>
        forms page
    </h5>
</div>