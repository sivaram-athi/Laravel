<div class="bg-white p-3 m-5">
    <h2>user Page</h2> 
    <hr>
    <h5>
        user page
    </h5>
</div>