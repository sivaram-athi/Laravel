<div class="bg-white p-3 m-5">
    <h2>Blank Page</h2> 
    <hr>
    <h5>
        dashboard page
    </h5>
</div>