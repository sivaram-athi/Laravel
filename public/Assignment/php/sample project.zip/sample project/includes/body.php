<div class="row bg-light p-5">
    <h4>Blog Search</h4>
    <div class="col-auto">
        <input type="password" id="inputPassword6" class="form-control" aria-describedby="passwordHelpInline">
    </div>
</div>
<div class="row bg-light p-5 mt-4">
    <h4>Blog categories</h4>
    <h6><a class="text-decoration-none" href="#">Category Name</a></h6>
    <h6><a class="text-decoration-none" href="#">Category Name</a></h6>
    <h6><a class="text-decoration-none" href="#">Category Name</a></h6>
    <h6><a class="text-decoration-none" href="#">Category Name</a></h6>
    <h6 class="mt-3"><a class="text-decoration-none" href="#">Category Name</a></h6>
    <h6><a class="text-decoration-none" href="#">Category Name</a></h6>
    <h6><a class="text-decoration-none" href="#">Category Name</a></h6>
    <h6><a class="text-decoration-none" href="#">Category Name</a></h6>
</div>

<div class="row bg-light p-5 mt-4">
    <h4>Side Widget Wall</h4>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quo quibusdam a perspiciatis? Fugiat quasi maxime vitae aut voluptatum voluptates laborum quam ad laudantium, esse, consectetur quia magnam facere officia nostrum.</p>
</div>